const projectList = [
  {
    title: "Школа сопровождаемого проживания",
    link: "/nashi-proekti/shkola-soprovozhdaemogo-prozhivaniya",
  },
  {
    title: "Трудовая реабилитация",
    link: "/nashi-proekti/trudovaya-reabilitaciya",
  },
  {
    title: "Волонтёрство для всех",
    link: "/nashi-proekti/volonterstvo-dlya-vseh",
  },
  {
    title: "Тренировочная квартира",
    link: "/nashi-proekti/trenirovochnaya-kvartira",
  },
  { title: "Выездные программы", link: "/nashi-proekti/viezdnye-programmy" },
];

module.exports = projectList;
