const projectsData = [
  {
    title: "Волонтерство для всех",
    description: "Помогая другим – помогаешь себе!",
    link: "/nashi-proekti/volonterstvo-dlya-vseh",
  },
  {
    title: "Трудовая реабилитация",
    description: "Помогая другим – помогаешь себе!",
    link: "/nashi-proekti/trudovaya-reabilitaciya",
  },
  {
    title: "Школа сопровождаемого проживания",
    highlight:
      "Соорганизаторы: Центр лечебной педагогики «Особое детство», Союз охраны психического здоровья",
    description:
      "Школа сопровождаемого проживания — межрегиональный проект Изумрудного города.",
    link: "/nashi-proekti/shkola-soprovozhdaemogo-prozhivaniya",
  },
  { title: "Выездные программы", link: "/nashi-proekti/viezdnye-programmy" },
  { title: "Курьеры для своих", link: "/nashi-proekti/trudovaya-reabilitaciya#courier" },
  { title: "Товары мастерских на озоне", link: "#" },
];

module.exports = projectsData;
