const partnersData = [
  { imageUrl: "images/patners/1.png", name: "1" },
  { imageUrl: "images/patners/2.png", name: "1" },
  { imageUrl: "images/patners/3.png", name: "1" },
  { imageUrl: "images/patners/4.png", name: "1" },
  { imageUrl: "images/patners/5.png", name: "1" },
  { imageUrl: "images/patners/6.png", name: "1" },
  { imageUrl: "images/patners/7.png", name: "1" },
  { imageUrl: "images/patners/8.png", name: "1" },
  { imageUrl: "images/patners/9.png", name: "1" },
  { imageUrl: "images/patners/10.png", name: "1" },
  { imageUrl: "images/patners/11.png", name: "1" },
  { imageUrl: "images/patners/12.png", name: "1" },
];

module.exports = partnersData;