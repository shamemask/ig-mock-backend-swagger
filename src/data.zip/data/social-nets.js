const socialLinks = [
  {
    imageUrl: "images/social-links/telegram-logo.svg",
    name: "Telegram",
    link: "t.com",
  },
  {
    imageUrl: "images/social-links/vk-logo.svg",
    name: "VK",
    link: "vk.com",
  },
];

module.exports = socialLinks;
