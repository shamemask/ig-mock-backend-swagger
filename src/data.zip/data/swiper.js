const picArray = [
  {
    url: 'images/logo/image.jpg',
    name: 'Никита Сусов',
    description: 'Директор',
    altPic: 'Никита Сусов',

  },
  {
    url: 'images/logo/image_30.png',
    name: 'Юлия Пузырей',
    description: 'Автор текстов о нас',
    altPic: 'Юлия Пузырей',

  },
  {
    url: 'images/logo/image_30.png',
    name: 'Анастасия Кормакова',
    description: 'Руководитель проекта «Волонтерство для всех',
    altPic: 'Анастасия Кормакова',

  },
  {
    url: 'images/logo/image_30.png',
    name: 'Элина Солодовникова',
    description: 'Тренер мастерских «Маленькая типография» и «Дом трав». Член Совета Организации',
    altPic: 'Элина Солодовникова',

  },
  {
    url: 'images/logo/image_30.png',
    name: 'Алина Худякова',
    description: 'Психолог проектов',
    altPic: 'Алина Худякова',
  },
  {
    url: 'images/logo/image_30.png',
    name: 'Алина Худякова',
    description: 'Психолог проектов',
    altPic: 'Алина Худякова',
  },
];

module.exports = picArray;
